Master Chief
for Half Live and Counter Strike 1.6

made by GreenPeace and sebastion, new textures by Scayer

How to install (Half Live):
I don�t have Half Live so I can�t test it with.
-Unzip the .zip file to any folder
-go to your half live "models" folder*
-rename the file you want to change with my model to (old filename)_original.mdl
-rename my model to the original model and copy it to the "models" folder


How to install (Counter Strike 1.6):
1. Unzip the .zip file to any folder
2. Go to your CS-folder*, then to "models", "player" and "gign".
3. Make a copy of gign.mdl, rename it to gign_original.mdl
4. Unzip the .zip file to the gign folder and overwrite gign.mdl
5. Start Counter Strike and Choose Counter Terrorist and GIGN

ENJOY!

original file:
http://www.fpsbanana.com/skins/18099

*you can find out the game path while right-clicking your shortcut of the game and clicking "find target"